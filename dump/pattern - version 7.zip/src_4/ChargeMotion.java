import java.util.ArrayList;
import java.util.Comparator;
import java.util.Timer;
import java.util.TimerTask;

public class ChargeMotion {
    private int countRadial = 32;
    private final long duration = 30;
    private Timer timer;
    private int countCharge;
    private double radius = 50;
    private double[] centerPoint = {0, 0};
    private double[][][] charges;
    private int iterationForStar;
    private int iterationForStraight;
    private int totalInteration;
    private ArrayList<Integer> validDirections;
    private FileOperation fileOperation;

    public ChargeMotion() {
        fileOperation = new FileOperation();
        this.countCharge = fileOperation.getPointsOfEachRadial();
        charges = new double[countRadial][countCharge][2];
        initPosition();
    }

    /**
     * moving iteration
     */
    public void iteration() {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                ChargeMotion.this.motion();
            }
        }, 0, duration);
    }

    /**
     * each motion
     */
    private void motion() {
        iterationForStar ++;
        iterationForStraight ++;
        totalInteration ++;
        for (int i = 0; i < countRadial; i++) {
            for (int j = 0; j < countCharge; j++) {
                charges[i][j] = newPosition(charges[i][j]);
            }
        }
        
        validationCommunicationForStar();
        validationCommunicationForStraight();
        // print();
    }

    /**
     * initial position of charges
     */
    private void initPosition() {
        for (int i = 0; i < countRadial; i++) {
            for (int j = 0; j < countCharge; j++) {
                double r = 10 + (j+1) * 40 / countCharge;
                double angle = Math.PI * 2 * (countRadial - i) / countRadial;
                charges[i][j][0] = r * Math.cos(angle) + centerPoint[0];
                charges[i][j][1] = r * Math.sin(angle) + centerPoint[1];
            }
        }
        //  print();
    }

    /**
     * get new position
     *
     * @param pos current position
     * @return new position
     */
    private double[] newPosition(double[] pos) {
        validDirections = getValidDirections(pos);
        int direction = validDirections.get((int) (Math.random() * validDirections.size()));
        switch (direction) {
            case 0:
                pos[1]--;//top
                break;
            case 1:
                pos[0]++;//right
                break;
            case 2:
                pos[1]++;//down
                break;
            case 3:
                pos[0]--;//left
                break;
        }
        return pos;
    }

    /**
     * get validation directions
     *
     * @param pos current position
     * @return array list of validation direction
     */
    private ArrayList<Integer> getValidDirections(double[] pos) {
        ArrayList<Integer> directions = new ArrayList<>();
        double[] upPos = new double[2];
        double[] rightPos = new double[2];
        double[] downPos = new double[2];
        double[] leftPos = new double[2];
        upPos[0] = pos[0];
        upPos[1] = pos[1] - 1;
        rightPos[0] = pos[0] + 1;
        rightPos[1] = pos[1];
        downPos[0] = pos[0];
        downPos[1] = pos[1] + 1;
        leftPos[0] = pos[0] - 1;
        leftPos[1] = pos[1];
        if (validationPosition(upPos)) {
            directions.add(0);
        }
        if (validationPosition(rightPos)) {
            directions.add(1);
        }
        if (validationPosition(downPos)) {
            directions.add(2);
        }
        if (validationPosition(leftPos)) {
            directions.add(3);
        }

        return directions;
    }

    /**
     * position is in certain area or not
     *
     * @param pos charge position
     * @return if position is certain, true
     */
    private boolean validationPosition(double[] pos) {
        if (Math.pow((pos[0] - centerPoint[0]), 2) + Math.pow((pos[1] - centerPoint[1]), 2) < Math.pow(radius, 2)) {
            return true;
        }
        return false;
    }

    /**
     * whether 5 charges communicate each other, or not
     */
    private void validationCommunicationForStar() {
        ArrayList<int[]> points = new ArrayList<>();

        for (int i = 0; i < countRadial; i++) {
            for (int j = 0; j < countCharge; j++) {
                //  all points be located within r > 10
                if (Math.abs(charges[i][j][0]) >= 10 && Math.abs(charges[i][j][1]) >= 10) {
                    points.add(new int[] {i, j});   // set begining point's position

                    for (int ii = 0; ii < countRadial; ii++) {
                        for (int jj = 0; jj < countCharge; jj++) {
                            //  all points be located within r > 10
                            if (Math.abs(charges[ii][jj][0]) >= 10 && Math.abs(charges[ii][jj][1]) >= 10) {
                                int [] newPoint = new int[] {ii, jj};
                                // start to recognize around fourth point in straight
                                if (points.size() % 4 == 0) {       
                                    if (isEnableForStar(points, newPoint)) {
                                        points.add(newPoint);
                                    }
                                } else {
                                    // Determine if a point lies on a straight line
                                    if (isEnableForStraight(points, newPoint)) {
                                        points.add(newPoint);
                                        ii = 0;
                                        jj = 0;
                                    }
                                }
                            }
                        }
                    }
                    output(points, "Star", iterationForStar);
                    
                    points.clear();
                }
                
            }
        }
    }

    private void writeFile(String str) {
        System.out.print(str);
        fileOperation.write(str);
    }

    /**
     * for straight line, current point is enable or not
     *
     * @param points   already existing group of points enable straight)
     * @param newPointPos point to add into group
     * @return if enable , true
     */
    private boolean isEnableForStraight(ArrayList<int[]> points, int[] newPointPos) {
        if (points.size() == 0) {
            return false;
        }

        double[] newPoint = new double[] {charges[newPointPos[0]][newPointPos[1]][0], charges[newPointPos[0]][newPointPos[1]][1]};

        for (int i = 0; i < points.size() - 1; i++) {
            double[] point1 = new double[] {charges[points.get(i)[0]][points.get(i)[1]][0], charges[points.get(i)[0]][points.get(i)[1]][1]};    
            if (isCommunicable(point1, newPoint)) {
                return false;
            }
        }
        int [] lastPointPos = points.get(points.size() - 1);
        double[] lastPoint = new double[] {charges[lastPointPos[0]][lastPointPos[1]][0], charges[lastPointPos[0]][lastPointPos[1]][1]};
        return isCommunicable(lastPoint, newPoint);
    }

    /**
     * whether distance between two point is less than 1, or not
     *
     * @param pos1 point1
     * @param pos2 point2
     * @return if less than 1, true
     */
    private boolean isCommunicable(double[] pos1, double[] pos2) {
        if (pos1[0] == pos2[0] && pos1[1] == pos2[1]) {
            return false;
        }
        if (Math.pow((pos1[0] - pos2[0]), 2) + Math.pow((pos1[1] - pos2[1]), 2) <= 1) {
            return true;
        }
        return false;
    }

    /**
     *  determine triangle
     *
     * @param points current four points formed straight
     * @param lastPoint the vertex of triangle
     * @return Boolean
     */
    private boolean isEnableForStar(ArrayList<int[]> points, int[] lastPoint) {
        // determines whether the last point does not coincide with the four points of a straight
        for (int [] point : points) {
            if (charges[point[0]][point[1]] == charges[lastPoint[0]][lastPoint[1]]) {
                return false;
            }
        }
        // All of R, S, T are vertexs of triangle
        double[] rPoint = charges[points.get(2)[0]][points.get(2)[1]];
        double[] sPoint = charges[points.get(3)[0]][points.get(3)[1]];
        double[] tPoint = charges[lastPoint[0]][lastPoint[1]];

        // judge what the all segments of triangle be within 0-1m
        if (isCommunicable(rPoint, tPoint) && isCommunicable(sPoint, tPoint) ) {
            // judge what the angle is equal or small than 90 deg
            double rsLen = Math.abs(Math.pow(rPoint[0] - sPoint[0], 2)) + Math.abs(Math.pow(rPoint[1] - sPoint[1], 2));
            double stLen = Math.abs(Math.pow(sPoint[0] - tPoint[0], 2)) + Math.abs(Math.pow(sPoint[1] - tPoint[1], 2));
            double trLen = Math.abs(Math.pow(tPoint[0] - rPoint[0], 2)) + Math.abs(Math.pow(tPoint[1] - rPoint[1], 2));

            if (rsLen + stLen >= trLen) {
                return true;
            }
        }
        return false;
    }

    /**
     * whether 5 charges communicate each other, or not
     */
    private void validationCommunicationForStraight() {
        ArrayList<int[]> points = new ArrayList<>();
        for (int i = 0; i < countRadial; i++) {
            for (int j = 0; j < countCharge; j++) {
                if (Math.abs(charges[i][j][0]) >= 10 && Math.abs(charges[i][j][1]) >= 10) {         // point musb located without 10m
                    int[] firstPoint = new int[2];
                    firstPoint[0] = i;
                    firstPoint[1] = j;
                    points.add(firstPoint);
                    for (int ii = 0; ii < countRadial; ii++) {
                        for (int jj = 0; jj < countCharge; jj++) {
                            if (Math.abs(charges[ii][jj][0]) >= 10 && Math.abs(charges[ii][jj][1]) >= 10) {         // point musb located without 10m
                                int[] point = new int[2];
                                point[0] = ii;
                                point[1] = jj;
                                if (isEnableForStraight(points, point)) {
                                    points.add(point);
                                    ii = 0;
                                    jj = 0;
                                }
                            }
                        }
                    }
                    output(points, "Straight", iterationForStraight);
                    points.clear();    
                }
            }
        }
    }

      /**
     * output points
     *
     * @param points
     */
    private void output(ArrayList<int[]> points, String iterationName, int iteration) {
        if (points.size() >= 5) {
            if (iteration != 0) {
                writeFile(iterationName + " Iteration : " + iteration + "\n");
                writeFile("Total Iteration : " + totalInteration + "\n");
            }
            for (int g = 0; g < points.size() - 1; g++) {
                String s = "P" + points.get(g)[0] + "-" + (points.get(g)[1] + 1) + ",";
                writeFile(s);
            }
            String s = "P" + points.get(points.size() - 1)[0] + "-" + (points.get(points.size() - 1)[1] + 1);
            writeFile(s + "\n");

            for (int [] point : points) {
                System.out.println("\t" + charges[point[0]][point[1]][0] + ", " + charges[point[0]][point[1]][1]);
            }
            if (iterationName == "Star") {
                iterationForStar = 0;
            }
            if (iterationName == "Straight") {
                iterationForStraight = 0;
            }
        }
    }

    /**
     * print by console mode
     */
    private void print() {
        System.out.println("--------------------------------------------------");
        String[][] draw = new String[100][100];
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 100; j++) {
                draw[i][j] = " ";
            }
        }
        for (int i = 0; i < countRadial; i++) {
            for (int j = 0; j < countCharge; j++) {
                draw[(int) charges[i][j][0]][(int) charges[i][j][1]] = "o";
            }
        }
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 100; j++) {
                System.out.print(draw[i][j]);
            }
            System.out.println("");
        }
        System.out.println("--------------------------------------------------");
    }

}
