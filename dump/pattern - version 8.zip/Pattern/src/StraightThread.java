import java.lang.Runnable;
import java.util.ArrayList;

public class StraightThread implements Runnable{

    private double[][][] charges;
    private ChargeMotion motion;

    public void run() {
        motion = new ChargeMotion("straight");
        charges = motion.getCharges();
        validation();
    }

    /**
     * whether 5 charges communicate each other, or not
     */
    private void validation() {
        ArrayList<int[]> points = new ArrayList<>();
        for (int i = 0; i < motion.getCountRadial(); i++) {
            for (int j = 0; j < motion.getCountCharge(); j++) {
                if (Math.abs(charges[i][j][0]) >= 10 && Math.abs(charges[i][j][1]) >= 10) {         // point musb located without 10m
                    int[] firstPoint = new int[2];
                    firstPoint[0] = i;
                    firstPoint[1] = j;
                    points.add(firstPoint);
                    for (int ii = 0; ii < motion.getCountRadial(); ii ++) {
                        for (int jj = 0; jj < motion.getCountCharge(); jj ++) {
                            if (Math.abs(charges[ii][jj][0]) >= 10 && Math.abs(charges[ii][jj][1]) >= 10) {         // point musb located without 10m
                                int[] point = new int[2];
                                point[0] = ii;
                                point[1] = jj;
                                if (motion.isEnableForStraight(points, point)) {
                                    points.add(point);
                                    ii = 0;
                                    jj = 0;
                                }
                            }
                        }
                    }
                    output(points);
                    points.clear();    
                }
            }
        }
    }

    private void output(ArrayList<int[]> points) {
        if (points.size() >= 5) {
            String str = "";
            if (motion.getIterationForStraight() != 0) {
                str = "Straight Iteration : " + motion.getIterationForStraight() + "\n"
                    + "Total Iteration : " + motion.getTotalIteration() + "\n";
                motion.writeFile(str);
                str = "";
            }
            
            for (int g = 0; g < points.size(); g ++) {
                str += "P" + points.get(g)[0] + "-" + (points.get(g)[1] + 1);
                str += g != points.size() - 1 ? "," : "\n";
            }
            
            for (int [] point : points) {
                str += "\t" + charges[point[0]][point[1]][0] + ", " + charges[point[0]][point[1]][1] + "\n";
            }

            motion.writeFile(str);
            motion.setIterationForStraight(0);
        }
    }
}
