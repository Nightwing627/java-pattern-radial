import java.io.*;
import java.util.Date;

public class FileOperation {
    private String inputFile;
    private String outputFile;
    private BufferedWriter bw;

    public FileOperation() {
        this.inputFile = "./input.txt";
        this.outLog();
        // this.outputFile = outFile();
        
    }

    /**
     * get points of a radial
     *
     * @return number of points
     */
    public int getPointsOfEachRadial() {
        int points = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            points = Integer.parseInt(br.readLine());
            System.out.println("getPointsOfEachRadial: " + points);
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return points;
    }

    /**
     * append string to output file
     *
     * @param str string to append
     */
    public void write(String str) {
        try {
            bw = new BufferedWriter(new FileWriter(outputFile, true));
            bw.append(str);
            bw.close();
        } catch (Exception e) {

        }

    }

    private String outFile() {
        Date date = new Date();
        String str = "output/"+(date.getYear() + 1900) + "-" + (date.getMonth() + 1) + "-" + date.getDate() + " " + date.getHours()  + date.getMinutes()+ date.getSeconds() + ".txt";
        return str;
    }

    private void outLog() {
        String dir = System.getProperty("user.dir");
        
        // directory from where the program was launched
        // e.g /home/mkyong/projects/core-java/java-io
        System.out.println(dir);
    }
}
