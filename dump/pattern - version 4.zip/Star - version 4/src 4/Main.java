import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
       startMotion();
    //	System.out.print("ss");
    }

    public static void startMotion() {

        ChargeMotion chargeMotion = new ChargeMotion();
        chargeMotion.iteration();
    }
}
