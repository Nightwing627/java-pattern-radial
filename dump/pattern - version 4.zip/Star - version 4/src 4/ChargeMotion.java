import java.util.ArrayList;
import java.util.Comparator;
import java.util.Timer;
import java.util.TimerTask;

public class ChargeMotion {
    private int countRadial = 32;
    private final long duration = 30;
    private Timer timer;
    private int countCharge;
    private double radius = 50;
    private double[] centerPoint = {0, 0};
    private double[][][] charges;
    private int countIteration;
    private ArrayList<Integer> validDirections;
    private FileOperation fileOperation;

    public ChargeMotion() {
        fileOperation = new FileOperation();
        this.countCharge = fileOperation.getPointsOfEachRadial();
        charges = new double[countRadial][countCharge][2];
        initPosition();
    }

    /**
     * moving iteration
     */
    public void iteration() {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                ChargeMotion.this.motion();
            }
        }, 0, duration);
    }

    /**
     * each motion
     */
    private void motion() {
        countIteration++;
        for (int i = 0; i < countRadial; i++) {
            for (int j = 0; j < countCharge; j++) {
                charges[i][j] = newPosition(charges[i][j]);
            }
        }
        validationCommunication();
        // print();
    }

    /**
     * initial position of charges
     */
    private void initPosition() {
        for (int i = 0; i < countRadial; i++) {
            for (int j = 0; j < countCharge; j++) {
                double r = 10 + (j+1) * 40 / countCharge;
                double angle = Math.PI * 2 * (countRadial - i) / countRadial;
                charges[i][j][0] = r * Math.cos(angle) + centerPoint[0];
                charges[i][j][1] = r * Math.sin(angle) + centerPoint[1];
            }
        }
        //  print();
    }

    /**
     * get new position
     *
     * @param pos current position
     * @return new position
     */
    private double[] newPosition(double[] pos) {
        validDirections = getValidDirections(pos);
        int direction = validDirections.get((int) (Math.random() * validDirections.size()));
        switch (direction) {
            case 0:
                pos[1]--;//top
                break;
            case 1:
                pos[0]++;//right
                break;
            case 2:
                pos[1]++;//down
                break;
            case 3:
                pos[0]--;//left
                break;
        }
        return pos;
    }

    /**
     * get validation directions
     *
     * @param pos current position
     * @return array list of validation direction
     */
    private ArrayList<Integer> getValidDirections(double[] pos) {
        ArrayList<Integer> directions = new ArrayList<>();
        double[] upPos = new double[2];
        double[] rightPos = new double[2];
        double[] downPos = new double[2];
        double[] leftPos = new double[2];
        upPos[0] = pos[0];
        upPos[1] = pos[1] - 1;
        rightPos[0] = pos[0] + 1;
        rightPos[1] = pos[1];
        downPos[0] = pos[0];
        downPos[1] = pos[1] + 1;
        leftPos[0] = pos[0] - 1;
        leftPos[1] = pos[1];
        if (validationPosition(upPos)) {
            directions.add(0);
        }
        if (validationPosition(rightPos)) {
            directions.add(1);
        }
        if (validationPosition(downPos)) {
            directions.add(2);
        }
        if (validationPosition(leftPos)) {
            directions.add(3);
        }

        return directions;
    }

    /**
     * position is in certain area or not
     *
     * @param pos charge position
     * @return if position is certain, true
     */
    private boolean validationPosition(double[] pos) {
        if (Math.pow((pos[0] - centerPoint[0]), 2) + Math.pow((pos[1] - centerPoint[1]), 2) < Math.pow(radius, 2)) {
            return true;
        }
        return false;
    }

    /**
     * whether 5 charges communicate each other, or not
     */
    private void validationCommunication() {
        //   writeFile("Iteration : " + countIteration + "\n");
        ArrayList<double[]> positions = new ArrayList<>();
        ArrayList<int[]> points = new ArrayList<>();
        for (int i = 0; i < countRadial; i++) {
            for (int j = 0; j < countCharge; j++) {
                positions.add(charges[i][j]);
                int[] point = new int[2];
                point[0] = i;
                point[1] = j;
                points.add(point);
                for (int ii = 0; ii < countRadial; ii++) {
                    for (int jj = 0; jj < countCharge; jj++) {
                        if (charges[i][j] != charges[ii][jj] && isCommunicable(charges[i][j], charges[ii][jj])) {
                            positions.add(charges[ii][jj]);
                            int[] point1 = new int[2];
                            point1[0] = ii;
                            point1[1] = jj;
                            points.add(point1);
                        }
                    }
                }
                if (points.size() >= 5) {
                    if (countIteration != 0) {
                        writeFile("Iteration : " + countIteration + "\n");
                    }
                    for (int g = 0; g < points.size() - 1; g++) {
                        String s = "P" + points.get(g)[0] + "-" + (points.get(g)[1] + 1) + ",";
                        writeFile(s);
                    }
                    String s = "P" + points.get(points.size() - 1)[0] + "-" + (points.get(points.size() - 1)[1] + 1);
                    writeFile(s + "\n");
                    countIteration = 0;
                }
                points.clear();
                positions.clear();
            }
        }
    }

    private void writeFile(String str) {
        System.out.print(str);
        fileOperation.write(str);
    }

    /**
     * whether distance between two point is less than 1, or not
     *
     * @param pos1 point1
     * @param pos2 point2
     * @return if less than 1, true
     */
    private boolean isCommunicable(double[] pos1, double[] pos2) {
        if (Math.pow((pos1[0] - pos2[0]), 2) + Math.pow((pos1[1] - pos2[1]), 2) <= 1) {
            return true;
        }
        return false;
    }

    /**
     * print by console mode
     */
    private void print() {
        System.out.println("--------------------------------------------------");
        String[][] draw = new String[100][100];
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 100; j++) {
                draw[i][j] = " ";
            }
        }
        for (int i = 0; i < countRadial; i++) {
            for (int j = 0; j < countCharge; j++) {
                draw[(int) charges[i][j][0]][(int) charges[i][j][1]] = "o";
            }
        }
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 100; j++) {
                System.out.print(draw[i][j]);
            }
            System.out.println("");
        }
        System.out.println("--------------------------------------------------");
    }

}
