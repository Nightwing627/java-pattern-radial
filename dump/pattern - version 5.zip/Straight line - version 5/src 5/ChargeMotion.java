import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class ChargeMotion {
    private int radials = 32;
    private final long duration = 30;
    private Timer timer;
    private int chargesPerRadial;
    private double radius = 50;
    private double[] centerPoint = {0, 0};
    private double[][][] charges;
    private int iterationForCircleFirstPoint;
    private int iterationForStraight;
    private int totalIteration;
    private ArrayList<Integer> validDirections;
    private FileOperation fileOperation;

    public ChargeMotion() {
        fileOperation = new FileOperation();
        this.chargesPerRadial = fileOperation.getPointsOfEachRadial();
        charges = new double[radials][chargesPerRadial][2];
        initPosition();
    }

    /**
     * moving iteration
     */
    public void iteration() {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                ChargeMotion.this.motion();
            }
        }, 0, duration);
    }

    /**
     * each motion
     */
    private void motion() {
        iterationForCircleFirstPoint++;
        iterationForStraight++;
        totalIteration++;
        for (int i = 0; i < radials; i++) {
            for (int j = 0; j < chargesPerRadial; j++) {
                charges[i][j] = newPosition(charges[i][j]);
            }
        }
    //    validationCommunicationForCircle();
        validationCommunicationForStraight();
        // print();
    }

    /**
     * initial position of charges
     */
    private void initPosition() {
        for (int i = 0; i < radials; i++) {
            for (int j = 0; j < chargesPerRadial; j++) {
                double r = 10 + (double) (j + 1) * 40 / chargesPerRadial;
                double angle = Math.PI * 2 * (radials - i) / radials;
                charges[i][j][0] = r * Math.cos(angle) + centerPoint[0];
                charges[i][j][1] = r * Math.sin(angle) + centerPoint[1];
            }
        }
        //  print(null);
    }

    /**
     * get new position
     *
     * @param pos current position
     * @return new position
     */
    private double[] newPosition(double[] pos) {
        validDirections = getValidDirections(pos);
        int direction = validDirections.get((int) (Math.random() * validDirections.size()));
        switch (direction) {
            case 0:
                pos[1]--;//top
                break;
            case 1:
                pos[0]++;//right
                break;
            case 2:
                pos[1]++;//down
                break;
            case 3:
                pos[0]--;//left
                break;
        }
        return pos;
    }

    /**
     * get validation directions
     *
     * @param pos current position
     * @return array list of validation direction
     */
    private ArrayList<Integer> getValidDirections(double[] pos) {
        ArrayList<Integer> directions = new ArrayList<>();
        double[] upPos = new double[2];
        double[] rightPos = new double[2];
        double[] downPos = new double[2];
        double[] leftPos = new double[2];
        upPos[0] = pos[0];
        upPos[1] = pos[1] - 1;
        rightPos[0] = pos[0] + 1;
        rightPos[1] = pos[1];
        downPos[0] = pos[0];
        downPos[1] = pos[1] + 1;
        leftPos[0] = pos[0] - 1;
        leftPos[1] = pos[1];
        if (validationPosition(upPos)) {
            directions.add(0);
        }
        if (validationPosition(rightPos)) {
            directions.add(1);
        }
        if (validationPosition(downPos)) {
            directions.add(2);
        }
        if (validationPosition(leftPos)) {
            directions.add(3);
        }

        return directions;
    }

    /**
     * position is in certain area or not
     *
     * @param pos charge position
     * @return if position is certain, true
     */
    private boolean validationPosition(double[] pos) {
        return Math.pow((pos[0] - centerPoint[0]), 2) + Math.pow((pos[1] - centerPoint[1]), 2) < Math.pow(radius, 2);
    }

    /**
     * whether 5 charges communicate each other, or not
     */
    private void validationCommunicationForCircle() {
        ArrayList<int[]> points = new ArrayList<>();
        for (int i = 0; i < radials; i++) {
            for (int j = 0; j < chargesPerRadial; j++) {
                int[] firstPoint = new int[2];
                firstPoint[0] = i;
                firstPoint[1] = j;
                points.add(firstPoint);
                for (int ii = 0; ii < radials; ii++) {
                    for (int jj = 0; jj < chargesPerRadial; jj++) {
                        int[] point = new int[2];
                        point[0] = ii;
                        point[1] = jj;
                        if (isCommunicable(points.get(0), point)) {
                            points.add(point);
                        }
                    }
                }
                if (points.size() >= 5) {
                    output(points, "Circle first point", iterationForCircleFirstPoint);
                    iterationForCircleFirstPoint = 0;
                }
                points.clear();
            }
        }
    }

    /**
     * whether 5 charges communicate each other, or not
     */
    private void validationCommunicationForStraight() {
        //  System.out.println("total : "+totalIteration);
        ArrayList<int[]> points = new ArrayList<>();
        for (int i = 0; i < radials; i++) {
            for (int j = 0; j < chargesPerRadial; j++) {
                int[] firstPoint = new int[2];
                firstPoint[0] = i;
                firstPoint[1] = j;
                points.add(firstPoint);
                for (int ii = 0; ii < radials; ii++) {
                    for (int jj = 0; jj < chargesPerRadial; jj++) {
                        int[] point = new int[2];
                        point[0] = ii;
                        point[1] = jj;
                        if (isEnableForStraight(points, point)) {
                            points.add(point);
                            ii = 0;
                            jj = 0;
                        }
                    }
                }
                if (points.size() >= 5 && iterationForStraight!=0) {
                    output(points, "Straight", iterationForStraight);
                    iterationForStraight = 0;
                    for (int k = 0; k < points.size(); k++) {
                        int c1 = points.get(k)[0];
                        int c2 = points.get(k)[1];
                        System.out.println("\t" + charges[c1][c2][0] + ", " + charges[c1][c2][1]);
                    }
                    //   print(pointsForStraight);
                }
                points.clear();
            }
        }
    }


    /**
     * whether distance between two point is less than 1, or not
     *
     * @param pos1 point1
     * @param pos2 point2
     * @return if less than 1, true
     */
    private boolean isCommunicable(int[] pos1, int[] pos2) {
        if (pos1[0] == pos2[0] && pos1[1] == pos2[1]) {
            return false;
        }
        return Math.pow((charges[pos1[0]][pos1[1]][0] - charges[pos2[0]][pos2[1]][0]), 2) + Math.pow((charges[pos1[0]][pos1[1]][1] - charges[pos2[0]][pos2[1]][1]), 2) <= 1;
    }

    /**
     * for straight line, current point is enable or not
     *
     * @param points   already existing group of points enable straight)
     * @param newPoint point to add into group
     * @return if enable , true
     */
    private boolean isEnableForStraight(ArrayList<int[]> points, int[] newPoint) {
        if (points.size() == 0) {
            return false;
        }
        for (int i = 0; i < points.size() - 1; i++) {
            if (isCommunicable(points.get(i), newPoint)) {
                return false;
            }
        }
        return isCommunicable(points.get(points.size() - 1), newPoint);
    }


    /**
     * output points
     *
     * @param points
     */
    private void output(ArrayList<int[]> points, String iterationName, int iteration) {
        if (iterationForCircleFirstPoint != 0) {
            writeFile(iterationName + " : " + iteration + "\n");
            writeFile("Total iteration : " + totalIteration + "\n");
        }
        for (int i = 0; i < points.size() - 1; i++) {
            String s = "P" + points.get(i)[0] + "-" + (points.get(i)[1] + 1) + ",";
            writeFile(s);
        }
        String s = "P" + points.get(points.size() - 1)[0] + "-" + (points.get(points.size() - 1)[1] + 1);
        writeFile(s + "\n");
    }

    /**
     * print file and console
     *
     * @param str
     */
    private void writeFile(String str) {
        System.out.print(str);
        fileOperation.write(str);
    }

    /**
     * print by console mode
     */
    private void print(ArrayList<int[]> points) {
        System.out.println("--------------------------------------------------");
        String[][] draw = new String[101][101];
        for (int i = 0; i < draw.length; i++) {
            for (int j = 0; j < draw[0].length; j++) {
                draw[i][j] = " ";
            }
        }
        if (points == null) {
            for (int i = 0; i < radials; i++) {
                for (int j = 0; j < chargesPerRadial; j++) {
                    draw[(int) charges[i][j][0] + 50][(int) charges[i][j][1] + 50] = "o";
                }
            }

        } else {
            for (int i = 0; i < points.size(); i++) {
                int c1 = points.get(i)[0];
                int c2 = points.get(i)[1];
                draw[(int) charges[c1][c2][0] + 50][(int) charges[c1][c2][1] + 50] = "o";
            }
        }
        //print
        for (int i = 0; i < draw.length; i++) {
            for (int j = 0; j < draw[0].length; j++) {
                System.out.print(draw[i][j]);
            }
            System.out.println("");
        }
        System.out.println("--------------------------------------------------");
    }

}
